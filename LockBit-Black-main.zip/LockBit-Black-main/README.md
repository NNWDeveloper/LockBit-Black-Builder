# LockBit-Black
LockBit Ransomware Builder

how to run it? just click Build.bat file.

and you can customize it in config.json
